# My First HTML Project — Volleyball

A single-page beginner website about volleyball, made with semantic HTML and an external CSS file.

## Project structure

- `index.html` — page content and semantic HTML
- `styles/style.css` — external styling (50+ lines)
- `README.md` — project notes

## Run locally

1. Open this folder in VS Code.
2. Open `index.html`.
3. Use Live Server if installed, or open `index.html` in your browser.

The hero image uses an external Unsplash URL, so an internet connection is needed to display it.

## Assignment checklist

- [x] Topic selected: Volleyball
- [x] Expository content: introduction and basic rules
- [x] Persuasive content: benefits and reasons to play
- [x] Quotations section with attribution
- [x] Semantic HTML: header, nav, main, section, article, aside, figure, blockquote, footer
- [x] External CSS file with more than 50 lines
- [ ] Validate HTML at https://validator.w3.org/
- [ ] Validate CSS at https://jigsaw.w3.org/css-validator/
- [ ] Create a GitHub repository named `my-first-html-project`
- [ ] Add and push the files to GitHub
- [ ] Submit the GitHub repository link

## Git commands

Run these in the VS Code terminal from this folder after creating the GitHub repository:

```bash
git init
git add .
git commit -m "Add HTML content and CSS styles"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/my-first-html-project.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your actual GitHub username. Do not run `git remote add origin` a second time if the remote is already configured.
